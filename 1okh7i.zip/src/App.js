import React from 'react'
import Header from './Components/Header'
import './App.css'
import AddNote from './Components/AddNote'
const App = () => {
  return (
    <div>

      <Header />
      <br />
      <br />
      <AddNote />
    </div>
  )
}

export default App
