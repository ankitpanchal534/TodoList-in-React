import React from "react";
import "./Header.css";

export default function Header() {
  return (
    <div>
      <header>
        <span> Google Notes </span>
        <span className="header-text-1">Devloped By Ankit Panchal</span>
      </header>
    </div>
  );
}
